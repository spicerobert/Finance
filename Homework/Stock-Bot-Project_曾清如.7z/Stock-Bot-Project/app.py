from flask import Flask, request, abort #匯入 Flask Web 框架，以及 request（接收請求）與 abort（出錯中止）
#匯入 LINE Bot SDK 中處理 LINE 訊息和事件的相關類別與功能
from linebot import LineBotApi, WebhookHandler
from linebot.exceptions import InvalidSignatureError
from linebot.models import MessageEvent, TextMessage, TextSendMessage, ImageSendMessage
#匯入你剛剛寫的 predict_trend() 函式，用來做股價預測並產生圖片
#from predictor import predict_trend
from predictorall import predict_and_plot  # 新增這行，匯入你整合的主程式函式
import os
import matplotlib
matplotlib.use("Agg")  # ❗️重要：讓 matplotlib 不使用 GUI 避免錯誤
# ✅ 你的 LINE Channel 金鑰
LINE_CHANNEL_ACCESS_TOKEN = 'WWW'
LINE_CHANNEL_SECRET = '555'

app = Flask(__name__, static_url_path="/static") #建立 Flask App，並將圖片放在 /static 路徑底下
#使用金鑰初始化 LINE Bot 客戶端與 Webhook 處理器
line_bot_api = LineBotApi(LINE_CHANNEL_ACCESS_TOKEN)
handler = WebhookHandler(LINE_CHANNEL_SECRET)
#當 LINE Bot 收到訊息時，LINE 會 POST 到這個 /callback 路由
@app.route("/callback", methods=['POST'])
def callback():#取得請求的簽章與主體內容（使用者傳的訊息）
    signature = request.headers['X-Line-Signature']
    body = request.get_data(as_text=True)
    print("[LOG] 收到 LINE 請求") 

    try:
        handler.handle(body, signature) #使用 handler 驗證並處理這次請求
    except InvalidSignatureError:
        print("[ERROR] LINE 簽名驗證失敗")
        abort(400) #如果驗證失敗，就終止請求（HTTP 400 錯誤)

    return 'OK' #回傳 OK 給 LINE 確認請求成功

@handler.add(MessageEvent, message=TextMessage)
def handle_message(event): #監聽「文字訊息」的事件
    stock_id = event.message.text.strip() #把使用者輸入的股票代碼讀進來並去除空白
    print(f"[LOG] 使用者輸入股票代碼：{stock_id}")

    image_path, analysis = predict_and_plot(stock_id)  # 改成呼叫整合的函式

    if image_path:
        # 自動產生 image_url（自動從 ngrok host 抓）
        host_url = request.host_url.replace("http://", "https://").strip("/")  # 確保 https
        image_url = f"{host_url}/static/{stock_id}_forecast.png" #自動產生圖片的 URL，確保使用 HTTPS 傳送給 LINE（否則會失敗）
        print(f"[LOG] 準備傳送圖片：{image_url}")

        line_bot_api.reply_message(
            event.reply_token,
            [
                TextSendMessage(text=analysis),
                ImageSendMessage(
                    original_content_url=image_url,
                    preview_image_url=image_url
                )
            ]
        ) #回傳兩則訊息：1.分析文字 2.預測圖
    else:
        print(f"[WARN] 查無資料，回應錯誤提示")
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text="❌ 查無資料，請輸入有效股票代碼（如：2330）")
        ) #若沒抓到資料或圖片，回應錯誤訊息

@app.route("/", methods=['GET']) #提供一個網站首頁，方便瀏覽器測試伺服器是否在運作。
def index():
    return "✅ LINE 股票預測機器人運行中"

if __name__ == "__main__":
    if not os.path.exists("static"): #若沒有 static 資料夾就自動建立，用來儲存圖片
        os.mkdir("static")
    print("[LOG] 啟動 Flask 伺服器（port: 3000）")
    app.run(port=3000) #在本地啟動 Flask 應用，監聽 3000 port

#✅ 總結功能流程
#使用者在 LINE 輸入股票代碼（如：2330）。
#程式抓取股價 → 預測 → 畫圖。
#回傳圖片 + 分析文字到 LINE。
#如果股票代碼錯誤或查不到資料，就回傳錯誤提示。