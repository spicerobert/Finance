import requests
import pandas as pd
from bs4 import BeautifulSoup
from datetime import datetime, timedelta
import yfinance as yf
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

# Gemini AI
import google.generativeai as genai
GEMINI_API_KEY = "AAA"  # 替換成你的實際金鑰
genai.configure(api_key=GEMINI_API_KEY)

plt.rcParams['font.family'] = 'Microsoft JhengHei'
plt.rcParams['axes.unicode_minus'] = False


def is_twse_stock(stock_id):
    url = "https://isin.twse.com.tw/isin/C_public.jsp?strMode=2"
    response = requests.get(url)
    response.encoding = "big5"
    soup = BeautifulSoup(response.text, "html.parser")
    table = soup.find_all("table")[0]
    rows = table.find_all("tr")[1:]  # Skip header

    for row in rows:
        cells = row.find_all("td")
        if len(cells) > 0:
            code = cells[0].text.strip().split(" ")[0]
            if code == stock_id:
                return True
    return False


def parse_minguo_date(date_str):
    y, m, d = map(int, date_str.split('/'))
    return datetime(y + 1911, m, d)


def get_stock_data_combined(stock_id, days=60, fallback=True):
    end_date = datetime.today()
    start_date = end_date - timedelta(days=days)

    def fetch_twse_data():
        all_data = []
        for i in range(3):  # 最近三個月
            target_date = end_date - pd.DateOffset(months=i)
            url = f"https://www.twse.com.tw/exchangeReport/STOCK_DAY?response=json&date={target_date.strftime('%Y%m%d')}&stockNo={stock_id}"
            try:
                res = requests.get(url)
                res.encoding = "utf-8"
                json_data = res.json()
                if 'data' in json_data:
                    for row in json_data['data']:
                        try:
                            date = parse_minguo_date(row[0])
                            if not (start_date <= date <= end_date):
                                continue
                            close_price = float(row[6].replace(',', ''))
                            open_price = float(row[3].replace(',', ''))
                            high_price = float(row[4].replace(',', ''))
                            low_price = float(row[5].replace(',', ''))
                            volume = int(row[1].replace(',', ''))
                            all_data.append([date, open_price, high_price, low_price, close_price, volume])
                        except Exception:
                            continue
            except Exception as e:
                print(f"[ERROR] TWSE 資料抓取失敗：{e}")
        return all_data

    def fetch_tpex_data():
        all_data = []
        for i in range(3):
            target_date = end_date - pd.DateOffset(months=i)
            url = f"https://www.tpex.org.tw/web/stock/aftertrading/daily_close_quotes/stk_quote_result.php?l=zh-tw&o=json&d={target_date.strftime('%Y/%m')}&s={stock_id}"
            try:
                res = requests.get(url)
                json_data = res.json()
                if 'aaData' in json_data:
                    for row in json_data['aaData']:
                        try:
                            date = parse_minguo_date(row[0])
                            if not (start_date <= date <= end_date):
                                continue
                            close_price = float(row[6].replace(',', ''))
                            open_price = float(row[3].replace(',', ''))
                            high_price = float(row[4].replace(',', ''))
                            low_price = float(row[5].replace(',', ''))
                            volume = int(row[1].replace(',', ''))
                            all_data.append([date, open_price, high_price, low_price, close_price, volume])
                        except Exception:
                            continue
            except Exception as e:
                print(f"[ERROR] TPEX 資料抓取失敗：{e}")
        return all_data

    # 判斷上市或上櫃
    is_twse = is_twse_stock(stock_id)
    print(f"[DEBUG] 股票 {stock_id} 為 {'上市' if is_twse else '上櫃'}")

    raw_data = fetch_twse_data() if is_twse else fetch_tpex_data()

    if raw_data:
        df = pd.DataFrame(raw_data, columns=["Date", "Open", "High", "Low", "Close", "Volume"])
        df = df.sort_values("Date")
        return df

    print(f"[WARN] TWSE/TPEX 查無資料")

    # fallback: Yahoo Finance
    if fallback:
        print(f"[INFO] 嘗試使用 Yahoo Finance 備援資料源")
        try:
            df_yf = yf.download(f"{stock_id}.TW", start=start_date.strftime("%Y-%m-%d"), end=end_date.strftime("%Y-%m-%d"), progress=False)
            if df_yf.empty:
                raise ValueError("Yahoo Finance 無資料")

            df_yf = df_yf.reset_index()
            df_yf = df_yf[['Date', 'Open', 'High', 'Low', 'Close', 'Volume']]
            df_yf = df_yf.sort_values("Date")
            return df_yf
        except Exception as e:
            print(f"[ERROR] Yahoo Finance 資料抓取失敗：{e}")

    return pd.DataFrame()  # 所有來源皆失敗



def predict_and_plot(stock_id, days=60):
    print(f"[LOG] 開始預測股票：{stock_id}")
    df = get_stock_data_combined(stock_id, days)
    if df.empty or len(df) < 30:
        print(f"[WARN] 資料不足（<30 筆）或查無資料")
        return None, None

    df_30 = df.tail(30).reset_index(drop=True)
    df_30["day"] = np.arange(len(df_30))
    X = df_30[["day"]]
    y = df_30["Close"]

    lr_model = LinearRegression().fit(X, y)

    future_days = 5
    future_X = np.arange(len(df_30), len(df_30) + future_days).reshape(-1, 1)
    future_y = lr_model.predict(future_X)

    plt.figure(figsize=(8, 5))
    plt.plot(df_30["Date"], df_30["Close"], label="歷史價格")
    future_dates = [df_30["Date"].iloc[-1] + timedelta(days=i + 1) for i in range(future_days)]
    plt.plot(future_dates, future_y, label="預測", linestyle="--", color='orange')

    plt.title(f"{stock_id} 近期走勢預測")
    plt.xlabel("日期")
    plt.ylabel("收盤價")
    plt.legend()
    plt.xticks(rotation=30, fontsize=8)
    plt.tight_layout()

    image_path = f"static/{stock_id}_forecast.png"
    try:
        plt.savefig(image_path)
        print(f"[LOG] 圖片儲存成功：{image_path}")
    except Exception as e:
        print(f"[ERROR] 圖片儲存失敗：{e}")
    plt.close()

    analysis = "📊 預測僅供參考\n"

    # ✅ 修正比較錯誤
    last_predicted = float(future_y[-1])
    last_close = float(df_30["Close"].iloc[-1])
    if last_predicted > last_close:
        analysis += "📈 預期短期有上漲趨勢"
        print(f"[LOG] 預測結果：上漲")
    else:
        analysis += "📉 預期短期可能下跌"
        print(f"[LOG] 預測結果：下跌")

    # ✅ Gemini AI 分析，這段現在也包在函數內部了
    try:
        latest_data = df_30[["Date", "Close"]].copy()
        latest_data["Date"] = latest_data["Date"].astype(str)
        text_summary = "\n".join([f"{row['Date']}: {row['Close']}" for _, row in latest_data.iterrows()])

        prompt = f"""
我提供你一檔台灣股票最近 30 天的收盤價（格式為 日期: 價格），請你用250字：
1. 分析目前的價格趨勢（如：多頭、空頭、盤整）
2. 指出是否有轉折跡象
3. 假設你是股票分析師，簡要評論技術面情況

資料如下：
{text_summary}
        """.strip()

        model = genai.GenerativeModel("gemini-1.5-flash")
        gemini_response = model.generate_content(prompt)
        gemini_analysis = gemini_response.text.strip()
        print("[LOG] Gemini 分析完成")
    except Exception as e:
        print("[ERROR] Gemini 分析錯誤：", e)
        gemini_analysis = "❌ Gemini 分析失敗"

    return image_path, analysis + "\n\n🤖 Gemini AI 分析：\n" + gemini_analysis




if __name__ == "__main__":
    stock_id = input("請輸入股票代碼（例：2330）：").strip()
    image_file, text_analysis = predict_and_plot(stock_id)
    if image_file and text_analysis:
        print(f"預測圖檔位置：{image_file}")
        print(text_analysis)
    else:
        print("無法取得有效資料，請確認股票代碼是否正確。")
